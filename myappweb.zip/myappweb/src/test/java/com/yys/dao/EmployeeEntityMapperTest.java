package com.yys.dao;

import com.yys.entity.EmployeeEntity;
import org.junit.runner.RunWith;


import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;


import static org.junit.Assert.*;

//配置spring和junit整合，这样junit在启动时就会加载spring容器
// SpringJUnit4ClassRunner requires JUnit 4.12 or higher.
@RunWith(SpringJUnit4ClassRunner.class)
//告诉junit spring的配置文件
//@ContextConfiguration({"classpath:/mapper/EmployeeEntityMapper.xml"})
@ContextConfiguration(locations = { "classpath*:/spring-mvc.xml",
        "classpath*:/spring-mybatis.xml"})
public class EmployeeEntityMapperTest {
    @Autowired
    private EmployeeEntityMapper employeeEntityMapper;
    @Test
    public void insert() {
        EmployeeEntity employeeEntity=new EmployeeEntity();
        employeeEntity.setJob("睡觉");
        employeeEntity.setSex("女");
        employeeEntity.setAge(24);
        employeeEntity.setAddress("b北京");
        employeeEntity.setEmployeeName("dfrrrr等等");

        //employeeEntityMapper.insert(employeeEntity);
        employeeEntityMapper.selectByPrimaryKey(49);
        employeeEntityMapper.selectByPrimaryKey(49);
        employeeEntityMapper.selectByPrimaryKey(49);
        employeeEntityMapper.selectByPrimaryKey(49);
        System.out.println(employeeEntity);
    }
}