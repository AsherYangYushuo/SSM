package com.yys.controller;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import static org.junit.Assert.*;
@RunWith(SpringJUnit4ClassRunner.class)
//告诉junit spring的配置文件
//@ContextConfiguration({"classpath:/mapper/EmployeeEntityMapper.xml"})
@ContextConfiguration(locations = { "classpath*:/spring-mvc.xml",
        "classpath*:/spring-mybatis.xml"})
public class EmployeeControllerTest {

    @Test
    public void getAllEmployee() {
        System.out.println("");
    }
}