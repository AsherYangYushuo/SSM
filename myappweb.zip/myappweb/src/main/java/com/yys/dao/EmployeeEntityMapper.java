package com.yys.dao;

import com.yys.entity.EmployeeEntity;

import java.util.List;

public interface EmployeeEntityMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(EmployeeEntity record);

    int insertSelective(EmployeeEntity record);

    EmployeeEntity selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(EmployeeEntity record);

    int updateByPrimaryKey(EmployeeEntity record);
    /**
     * 查询所有员工信息
     */
    List<EmployeeEntity> selectAllEmployee();
}