package com.yys.controller.validation;

/**
 * @InterfaceName:validateGroup1
 * @Description:分组校验2
 * @Author:YangYushuo
 * @Date:2018/11/1518:44
 * @Version:1.0
 */
public interface ValidateGroup2 {
    //分组校验接口中不需要定义任何方法

}
