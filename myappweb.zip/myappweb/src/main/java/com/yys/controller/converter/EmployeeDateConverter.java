package com.yys.controller.converter;

import org.springframework.core.convert.converter.Converter;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * <p>Title: EmployeeDateConverter</p>
 * <p>Description: </p>
 * <p>Company:www.com.yys</p>
 *
 * @Author: YangYushuo
 * @Date: 2018/11/9 12:23
 * @Version: 1.0
 */
public class EmployeeDateConverter  implements Converter<String,Date>{
    @Override
    public Date convert(String source) {
       // 将日期字符串转成日期类型(格式是：yyyy-MM-dd HH:mm:ss)
        String pattern="yyyy-MM-dd HH:mm:ss";
        SimpleDateFormat simpleDateFormat=new SimpleDateFormat(pattern);
        try{
           return simpleDateFormat.parse(source);
        }catch(ParseException e){
            e.printStackTrace();
        }
        //转换失败返回null
        return null;
    }
}
