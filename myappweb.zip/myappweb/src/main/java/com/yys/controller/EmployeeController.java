package com.yys.controller;

import com.base.bean.AjaxJson;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.yys.controller.validation.ValidateGroup1;
import com.yys.controller.validation.ValidateGroup2;
import com.yys.entity.EmployeeEntity;
import com.yys.service.Impl.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.util.List;
import java.util.UUID;

/**
 * @ClassName:EmployeeController
 * @Description:Controller
 * @Author:YangYushuo
 * @Date:2018/10/24 9:58
 * @Version:1.0
 */
@Controller
@RequestMapping("/employeeEntity")
public class EmployeeController {
    //每页的条数
    private static final Integer PAGESIZE = 5;
    @Autowired
    private EmployeeService employeeService;

    /**
     * 获取所有员工列表
     *
     * @param request
     * @param model
     * @param pageNo  当前页
     */
    @RequestMapping("/getAllEmployee")
    //@RequestParam进行简单类型的参数绑定
    public String getAllEmployee(HttpServletRequest request, Model model,
                                 @RequestParam(defaultValue = "1", required = true, value = "pageNo"
                                 ) Integer pageNo) throws Exception {
        //开始分页，先分页，后查询，否则pageSize会出错
        System.out.println(request.getParameter("id"));
        PageHelper.startPage(pageNo, PAGESIZE);
        List<EmployeeEntity> list = employeeService.selectAllEmployee();
        PageInfo<EmployeeEntity> pageInfo = new PageInfo<EmployeeEntity>(list);
        model.addAttribute("pageInfo", pageInfo);
       /* ModelAndView modelAndView=new ModelAndView();
        modelAndView.addObject("pageInfo", pageInfo);
        modelAndView.setViewName("/allEmployee");
        return modelAndView;*/
       /*Controller返回字符串类型，代表返回的逻辑视图名，
        真正视图（jsp文件路径=视图映射器配置的视图前缀+逻辑视图名+视图映射器配置的视图后缀）*/
        return "/allEmployee";

    }

    /**
     * 跳转到添加员工页面
     *
     * @param request
     * @return
     */
    @RequestMapping("/toAddEmployee")
    public String toAddEmployee(HttpServletRequest request) {
        return "/addEmployee";
    }

    /**
     * 添加员工并重定向
     *
     * @param employeeEntity
     * @param model
     * @return
     */
    /*EmployeeEntity employeeEntity这个参数是pojo参数绑定，pojo参数绑定有可能传进来post中文乱码,
     需要在web.xml当中添加编码过滤器
    pojo参数绑定成功的前提：页面input 的name属性要和controller中的pojo形参类型的属性名一致，
    若包装类型不是简单的包装类型，而是pojo包装pojo（比如UserCustom类中有一个属性是User,我们要传User的name属性）,
    那么页面传参时的input 的name属相值要等于内层包装类型.要穿的属性名（user.name）,多层包装的话以此类推


    日期类型的请求参数自定义参数绑定：
    假如页面有个自定义的日期格式的input，springMVC没有办法实现这种不固定的格式的数据的参数绑定，此时就需要自定义参数绑定
    例如：页面上有<input name="createTime" value="<fmt:formatDate value="${item.createTime}" pattern="yyyy-MM-dd HH:mm:ss"/>"/>
    对于controller中方中pojo类型的形参，如果其中有日期类型，那么这个日期类型就需要自定义参数绑定
    此时自定义参数绑定需要将页面的请求日期字符串转换成日期类型的对象，
    这个日期类型要和你pojo中的日期属性类型一致（util包和sql包中都有Date类型）
    1.需要向适配处理器中注入我们自定义的参数绑定组件
    在注解驱动 <mvc:annotation-driven/>中添加属性conversion-service="conversionService"
    <mvc:annotation-driven conversion-service="conversionService"/>
    自定义参数绑定
            <bean id="conversionService" class="org.springframework.format.support.FormattingConversionServiceFactoryBean">
        <!--注入自己写的conversion参数绑定转化器-->
        <property name="converters">
            <list>
                <!--日期类型的装换-->
                <bean class="com.yys.controller.converter.EmployeeDateConverter"></bean>
                <!--其他类型，比方说字符串去空格的转换等-->
                <!--<bean></bean>-->
            </list>
        </property>
    </bean>

    2.定义自己的参数绑定组件 EmployeeDateConverter 实现Converter接口
    public class EmployeeDateConverter  implements Converter<String,Date>{
    @Override
    public Date convert(String source) {
       // 将日期字符串转成日期类型(格式是：yyyy-MM-dd HH:mm:ss)
        String pattern="yyyy-MM-dd HH:mm:ss";
        SimpleDateFormat simpleDateFormat=new SimpleDateFormat(pattern);
        try{
           return simpleDateFormat.parse(source);
        }catch(ParseException e){
            e.printStackTrace();
        }
        //转换失败返回null
        return null;
    }
}
    */
    @RequestMapping("/addEmployee")
    public String addEmployee(EmployeeEntity employeeEntity, Model model) throws Exception {
        employeeService.insert(employeeEntity);
        System.out.println(employeeEntity.getId());
        return "redirect:/employeeEntity/getAllEmployee";
    }

    /**
     * 编辑员工信息并重定向
     *
     * @param employeeEntity
     * @param request
     * @param model
     * @return
     */
    // @RequestMapping("/updateEmployee")
    //第一点：在需要校验的pojo处前面添加@Validated 注解，在需要校验的pojo后面添加BindingResult bindingResult参数来接受校验错误信息
    //注意如果要校验多个pojo,那么每个pojo和BindingResult是配对出现的，并且顺序是固定的。
    //第二点：数据回显，springMVC 将pojo传给controller中的方法时，会自动将pojo放入request域中，key值就是pojo类型（首字母小写），
    // 前段页面可以通过${pojo名.属性}来实现自动回显
    //也可以通过@ModelAttribute("页面key名")，来指定pojo回显到前端页面在pojo中的key值
    //第三点：@ModelAttribute("key名")，还可以注释controller中的方法，将改方法的返回值放到request域中，供页面取用
    @RequestMapping(value = "/updateEmployee", method = {RequestMethod.POST})
    public String updateEmployee(@ModelAttribute("employee") @Validated(value = {ValidateGroup2.class}) EmployeeEntity employeeEntity,
                                 BindingResult bindingResult,
                                 HttpServletRequest request,
                                 Model model, Integer pageNo,
                                 HttpServletResponse response,
                                 MultipartFile employee_pic//用来接收页面传过来的图片
    ) throws Exception {
        if (bindingResult.hasErrors()) {
            List<ObjectError> allErrors = bindingResult.getAllErrors();
            for (ObjectError objectError : allErrors) {
                System.out.println(objectError.getDefaultMessage());
            }
            model.addAttribute("allErrors", allErrors);
            return "/editEmployee";
        }
        //上传图片
        String originalFilename = employee_pic.getOriginalFilename();//获取原始图片名称

        if(employee_pic!=null&&originalFilename!=null&&originalFilename.length()>0){
            //存储图片的物理路径
            String pic_path = "D:\\develop\\upload\\temp\\";

            //生成新的图片名称,uuid随机数+拓展名
            String newFileName = UUID.randomUUID() +
                    originalFilename.substring(originalFilename.lastIndexOf("."));
            //新图片
            File newFile=new File(pic_path+newFileName);
            //将内存中的数据写入服务器磁盘
            employee_pic.transferTo(newFile);
            //将上传的图片名称写入到employeeEntity中
            employeeEntity.setEmployeePic(newFileName);

        }
        if (employeeService.updateByPrimaryKey(employeeEntity) > 0) {
            // employeeEntity = employeeService.selectByPrimaryKey(employeeEntity.getId());
            // model.addAttribute("employee", employeeEntity);
            /*1.redirect重定向特点：浏览器url地址改变，重定向后会重新进行request请求，
             原来的request请求数据不会传到新请求
           重定向的方式：return:"redirect:getAllEmployee"(注意不能写成redirect:/getAllEmployee)或者写成return:"redirect:/employeeEntity/getAllEmployee""
            这里可以不用带根路径/employeeEntity,因为在同一个controller中
            2.forword页面转发特点：url地址不变，request请求数据可以共享
            页面转发方式是：return "forward:getAllEmployee";
           3.controller中的方法返回结果如果是void类型，那么方法中一般会有参数request、response，方法中对请求的处理一般可以后三种方法方式：
            第一：request请求forward转发：request.get
             request.getRequestDispatcher("页面路径").forward(request,response);
            第二：response重定向
            response.sendRedirect("url")
            第三：通过response指定相应结果
            response.setCharacterEncoding("utf-8");
            response.setContentType("application/json:charset=utf-8");
            response.getWriter().write("json串");
            */

            return "forward:getAllEmployee";
        } else {
            return "/error";
        }
    }

    /**
     * 按照id查询Employee信息
     *
     * @param id
     * @param request
     * @param model
     * @return
     */
    //SpringMVC 支持RESTful风格的开发
    //RESTful是一种开发理念，包括url模板开发和请求时指定contentType，要json数据就指定成json格式
    //URL模板开发，浏览器请求的格式是http://.../items/id/type
    //URL模板开发，controller层方法接收请求的映射模板是/items/{id},
    // controller方法参数格式是@PathVariable("id") Integer id

    @RequestMapping("/getEmployee/{id}")
    public String getEmployeeById(@PathVariable("id") Integer id, HttpServletRequest request, Model model) throws Exception {
        model.addAttribute("employee", employeeService.selectByPrimaryKey(id));
        return "/editEmployee";
    }



    /**
     * 删除员工
     * @param employeeEntity
     * @return
     * @throws Exception
     */
    @RequestMapping("/deleteEmployee")
    @ResponseBody
    //public AjaxJson deleteEmployee(@RequestBody String id) throws Exception {
    public AjaxJson deleteEmployee(@RequestBody EmployeeEntity employeeEntity) throws Exception {
        AjaxJson ajaxJson = new AjaxJson();
        //int b = employeeService.deleteByPrimaryKey(Integer.parseInt(id.split("=")[1]));
        int b = employeeService.deleteByPrimaryKey(employeeEntity.getId());
        if (b > 0) {
            ajaxJson.setCode(200);
            ajaxJson.setMsg("刪除成功");
        } else {
            ajaxJson.setMsg("刪除失敗");
            ajaxJson.setCode(400);
        }
        return ajaxJson;
    }
   /*
   数组类型、List、Map的参数绑定
   1.数组类型
   页面：使用<c:foreach items="${itemList}" var="item"></c:forEach>循环嵌套checkBox
   <form action="${pageContext.request.contextPath }/getlist.action" method="post">
查询条件：
    <table width="100%" border=1>
    <tr>
    <td><input type="submit" value="查询"/></td>
    </tr>
    </table>
    商品列表：
    <table width="100%" border=1>
    <tr>
        <td>商品名称</td>
        <td>商品价格</td>
        <td>生产日期</td>
        <td>商品描述</td>
        <td>操作</td>
    </tr>
    <c:forEach items="${itemList }" var="item" >
    <tr>
        <td><input type="checkbox" name="ids" value="${item.id}">${item.name }</td>
        <td>${item.price }</td>
        <td><fmt:formatDate value="${item.createtime}" pattern="yyyy-MM-dd HH:mm:ss"/></td>
        <td>${item.detail }</td>

        <td><a href="${pageContext.request.contextPath }/itemEdit.action?id=${item.id}">修改</a></td>

    </tr>
    </c:forEach>
    </table>
    <input type="submit" value="查询"/>
</form>
controller层：
  @RequestMapping(value = "/ids.action")
    public ModelAndView getids(Integer[] ids) {
        for (int i : ids) {
            System.out.println(i);
        }
     }
2.list参数绑定
页面： 使用<c:foreach items="${itemList}" var="item" varStatus="status">
               // input的name要是pojo类型里pojo1属性名.pojo1.属性名，list传参时那么格式是："list属性名[${status.index}]"
            <input type="text" name="list[${status.index}].name" value="${item.name }">
        </c:foreach

<form action="${pageContext.request.contextPath }/getlist.action" method="post">
查询条件：
    <table width="100%" border=1>
    <tr>
    <td><input type="submit" value="查询"/></td>
    </tr>
    </table>
    商品列表：
    <table width="100%" border=1>
    <tr>
        <td>商品名称</td>
        <td>商品价格</td>
        <td>生产日期</td>
        <td>商品描述</td>
        <td>操作</td>
    </tr>
    <c:forEach items="${itemList }" var="item" varStatus="status">
    <tr>
        <td><input type="text" name="list[${status.index}].name" value="${item.name }"></td>
        <td><input type="text" name="list[${status.index}].price" value="${item.price }"></td>
        <td><fmt:formatDate value="${item.createtime}" pattern="yyyy-MM-dd HH:mm:ss"/></td>
        <td>${item.detail }</td>

        <td><a href="${pageContext.request.contextPath }/itemEdit.action?id=${item.id}">修改</a></td>

    </tr>
    </c:forEach>
    </table>
    <input type="submit" value="查询"/>
</form>
controller层：方法中形参为一个包装了list的pojo类型
  public ModelAndView getList(QueryVo list) {
        for (Items s : list) {
            System.out.println(s);
        }
        //代码自己补
    }
3.map类型参数绑定
页面：input的name要是pojo类型里pojo1属性名.pojo1.属性名，map传参时那么格式是："map属性名['map的key名']"

    controller层：方法中形参为一个包装了map的pojo类型
    public ModelAndView getList(QueryVo queryInfo) {
       Map map=queryInfo.getmap属性名
        for (Map.Entry<Integer, Integer> entry : map.entrySet()) {
          System.out.println("Key = " + entry.getKey() + ", Value = " + entry.getValue());
        }
        //代码自己补
    }
    */

}
