package com.yys.exception;

/**
 * <p>Title: EmployeeException</p>
 * <p>Description: 自定义预期异常类</p>
 * <p>Company:www.com.yys</p>
 *
 * @Author: YangYushuo
 * @Date: 2018/11/16 9:34
 * @Version: 1.0
 */
public class EmployeeException extends   Exception {
    public String message;

    public EmployeeException(String message) {
        super(message);
        this.message = message;
    }

    @Override
    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
