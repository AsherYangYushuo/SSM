package com.yys.exception;

import org.springframework.web.servlet.HandlerExceptionResolver;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * <p>Title: EmployeeExceptionResolver</p>
 * <p>Description: </p>
 * <p>Company:www.com.yys</p>
 *
 * @Author: YangYushuo
 * @Date: 2018/11/16 9:47
 * @Version: 1.0
 */
public class EmployeeExceptionResolver implements HandlerExceptionResolver {
    @Override
    public ModelAndView resolveException(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o, Exception e) {
        EmployeeException employeeException=null;
        if(e instanceof EmployeeException ){
            employeeException= (EmployeeException) e;
        }else{
            employeeException=new  EmployeeException(e.getMessage()) ;
        }
        String message=employeeException.getMessage();
        ModelAndView modelAndView=new ModelAndView();
        modelAndView.addObject("message",message);
        modelAndView.setViewName("/error");
        return modelAndView;
    }
}
