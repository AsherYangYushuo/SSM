package com.yys.entity;


import com.yys.controller.validation.ValidateGroup1;
import com.yys.controller.validation.ValidateGroup2;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.Date;

/**
 * 使用Mybatis-generator自动生成的实体类EmployeeEntity
 */
public class EmployeeEntity implements Serializable{

    private static final long serialVersionUID = 8772359517547139754L;
    private Integer id;

    @NotEmpty(message = "{EmployeeEntity.job.isNull}",groups = {ValidateGroup2.class})
    private String job;

    private String address;

    private Integer age;

    private String sex;
//校验名称在1-30字符之间
    @Size(min = 1,max = 30,message = "{EmployeeEntity.employeeName.length.error}",
            groups = {ValidateGroup1.class,ValidateGroup2.class})
    private String employeeName;
    private String employeePic;
    @NotNull(message = "{EmployeeEntity.createTime.isNull}",groups = {ValidateGroup2.class})
    private Date createTime;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getJob() {
        return job;
    }

    public void setJob(String job) {
        this.job = job == null ? null : job.trim();
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address == null ? null : address.trim();
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex == null ? null : sex.trim();
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName == null ? null : employeeName.trim();
    }

    public String getEmployeePic() {
        return employeePic;
    }

    public void setEmployeePic(String employeePic) {
        this.employeePic = employeePic == null ? null : employeePic.trim();
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    @Override
    public String toString() {
        return "EmployeeEntity{" +
                "id=" + id +
                ", job='" + job + '\'' +
                ", address='" + address + '\'' +
                ", age=" + age +
                ", sex='" + sex + '\'' +
                ", employeeName='" + employeeName + '\'' +
                ", employeePic='" + employeePic + '\'' +
                ", createTime=" + createTime +
                '}';
    }
}