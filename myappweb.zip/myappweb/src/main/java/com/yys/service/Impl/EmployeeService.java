package com.yys.service.Impl;

import com.yys.entity.EmployeeEntity;

import java.util.List;

/**
 * @InterfaceName:EmployeeService
 * @Description:
 * @Author:YangYushuo
 * @Date:2018/11/5 9:30
 * @Version:1.0
 */
public interface EmployeeService {
    int deleteByPrimaryKey(Integer id) throws  Exception;


    int insert(EmployeeEntity record)  throws  Exception;


    int insertSelective(EmployeeEntity record)  throws  Exception;


    EmployeeEntity selectByPrimaryKey(Integer id)  throws  Exception;


    int updateByPrimaryKeySelective(EmployeeEntity record)  throws  Exception;


    int updateByPrimaryKey(EmployeeEntity record)  throws  Exception;

    List<EmployeeEntity> selectAllEmployee()  throws  Exception;
}
