package com.yys.service.Impl;

import com.yys.dao.EmployeeEntityMapper;
import com.yys.entity.EmployeeEntity;
import com.yys.exception.EmployeeException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;


/**
 * @ClassName:EmployeeServiceImpl
 * @Description:
 * @Author:YangYushuo
 * @Date:2018/10/23 21:35
 * @Version:1.0
 */
@Service
@Transactional
public class EmployeeServiceImpl implements EmployeeService {

    @Autowired
    private EmployeeEntityMapper employeeEntityMapper;
/**
 * SpringMVC 中的异常处理
 * 1.异常处理流程：dao层向上抛出异常到service层，service层向上抛出异常到controller层，
 * controller层向上抛出异常到前端控制器DispatcherServlet，前端处理器不能再抛出了，它要处理异常
 * 2.全局异常处理器
 * 异常：系统中异常分为预期异常和runtime运行时异常，全局异常处理器可以对异常进行统一处理，一个系统只有一个全局异常处理器
 * 定义步骤：
 * 第一：对于预期异常自定义异常类 extends Exception
 * 第二：定义全局异常处理器，implements HandlerExceptionResolver,内部的主要逻辑
 *  解析出异常类型，
 *  如果异常类型是自定义的预期异常，那么直接取出异常信息，在页面展示
 *  如果不是预期异常，那么构造一个自定义异常类，取出异常，在页面展示
 *第三：在springmvc中配置全局异常处理器
 *
 */

    @Override
    public int deleteByPrimaryKey(Integer id) throws Exception  {
        return employeeEntityMapper.deleteByPrimaryKey(id);
    }
    /**
     * 插入一条数据
     *
     * @param record
     */
    @Override
    public int insert(EmployeeEntity record)  throws  Exception {
        return employeeEntityMapper.insert(record);
    }
    /**
     * 选择性插入一条数据
     *
     * @param record
     */
    @Override
    public int insertSelective(EmployeeEntity record) throws  Exception {
        return employeeEntityMapper.insertSelective(record);
    }
//
    @Override
    public EmployeeEntity selectByPrimaryKey(Integer id)  throws  Exception{
        EmployeeEntity employeeEntity=null;
        employeeEntity=employeeEntityMapper.selectByPrimaryKey(id);
        if(employeeEntity==null){
            throw new EmployeeException("员工信息查询错误，未查到！id="+id);
        }
        return employeeEntity;
    }

    @Override
    public int updateByPrimaryKeySelective(EmployeeEntity record) throws  Exception {
        return employeeEntityMapper.updateByPrimaryKeySelective(record);
    }

    @Override
    public int updateByPrimaryKey(EmployeeEntity record) throws  Exception {
        return employeeEntityMapper.updateByPrimaryKey(record);
    }

    @Override
    public List<EmployeeEntity> selectAllEmployee() throws  Exception {
        return employeeEntityMapper.selectAllEmployee();
    }
}