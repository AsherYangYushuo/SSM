package com.yys.interceptor;

import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * <p>Title: HandlerInterceptor1</p>
 * <p>Description: springMVC拦截器</p>
 * <p>Company:www.com.yys</p>
 *
 * @Author: YangYushuo
 * @Date: 2018/11/19 10:39
 * @Version: 1.0
 */
public class HandlerInterceptor1 implements HandlerInterceptor{
    //进入Handler方法之前执行
    //应用场景：身份认证，身份授权等，认证不通过return false
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        return false;
    }
    //进入handler方法以后，返回ModelAndView之前执行
    //应用场景：将公用的模型数据传入ModelAndView视图，例如导航菜单等，
    // 也可以在这里统一指定视图
    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {

    }
//handler方法执行完以后执行
        //统一的异常处理、统一的日志处理等
    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {

    }
}
